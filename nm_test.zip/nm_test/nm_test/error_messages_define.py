
## Below data are the define of all known error types :

IPMI_SEND_ERROR  = '!!! IPMI SEND ERROR!!! No data respond. Please check your IPMI cmd interface is stable without Timeout'
ME_OEM_RSP_ERROR = '!!! SPS FW RESPOND UNEXPECTED DATA. Please check if SPS FW IN OPERATION MODE and NM FW configuation correct'
ME_Sensor_RSP_ERROR = '!!! SPS FW RESPOND UNEXPECTED DATA. Please check if SPS FW IN OPERATION MODE and NM FW configuation correct'
